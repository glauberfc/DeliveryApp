/* Amplify Params - DO NOT EDIT
	API_DELIVERINGHOPEAPI_GRAPHQLAPIENDPOINTOUTPUT
	API_DELIVERINGHOPEAPI_GRAPHQLAPIIDOUTPUT
	ENV
	REGION
Amplify Params - DO NOT EDIT */

exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
